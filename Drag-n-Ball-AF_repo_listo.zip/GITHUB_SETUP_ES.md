# Compilar en GitHub
1. Crea un repositorio vacío.
2. Descomprime este ZIP y sube el contenido de esta carpeta a la raíz del repositorio.
3. Abre Actions y ejecuta **Build Forge mod**.
4. Descarga el artefacto `legacy-of-the-saiyans-forge-1.20.1` cuando termine.
5. Si falla, comparte el log de error para corregirlo.

Un build correcto confirma que compila, no que todas las funciones estén implementadas o probadas en Zalith.
