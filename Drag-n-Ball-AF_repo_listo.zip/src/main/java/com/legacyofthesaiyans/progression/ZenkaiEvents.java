package com.legacyofthesaiyans.progression;

import com.legacyofthesaiyans.LegacyOfTheSaiyans;
import com.legacyofthesaiyans.config.LegacyConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/**
 * First playable progression slice:
 * tracks damage received, awards a permanent Zenkai on death, copies it
 * across the death/respawn player clone, and reapplies its combat bonus.
 *
 * The full Other World dimension, UI, balance and multiplayer sync are later milestones.
 */
@Mod.EventBusSubscriber(modid = LegacyOfTheSaiyans.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ZenkaiEvents {
    private static final String ROOT = LegacyOfTheSaiyans.MOD_ID + ".";
    private static final String DAMAGE_SINCE_LAST_ZENKAI = ROOT + "damage_since_zenkai";
    private static final String PERMANENT_ZENKAI = ROOT + "permanent_zenkai";
    private static final String ZENKAI_COUNT = ROOT + "zenkai_count";
    private static final UUID ZENKAI_ATTACK_UUID =
            UUID.fromString("5a2bcd71-6f44-4a42-9a41-4e7b9c8c1a10");

    private ZenkaiEvents() {}

    @SubscribeEvent
    public static void onPlayerHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getAmount() <= 0.0F) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        double previous = data.getDouble(DAMAGE_SINCE_LAST_ZENKAI);
        data.putDouble(DAMAGE_SINCE_LAST_ZENKAI, previous + event.getAmount());
    }

    @SubscribeEvent
    public static void onPlayerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)
                || !LegacyConfig.ENABLE_PERMANENT_ZENKAI.get()) {
            return;
        }

        CompoundTag data = player.getPersistentData();
        double damage = data.getDouble(DAMAGE_SINCE_LAST_ZENKAI);

        // Small, permanent progression reward. Balancing will be refined with real gameplay tests.
        double reward = Math.max(1.0D, Math.sqrt(Math.max(1.0D, damage)) * 0.10D);
        double total = data.getDouble(PERMANENT_ZENKAI);
        data.putDouble(PERMANENT_ZENKAI, total + reward);
        data.putInt(ZENKAI_COUNT, data.getInt(ZENKAI_COUNT) + 1);
        data.putDouble(DAMAGE_SINCE_LAST_ZENKAI, 0.0D);
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.isWasDeath()) {
            return;
        }
        CompoundTag oldData = event.getOriginal().getPersistentData();
        CompoundTag newData = event.getEntity().getPersistentData();
        copyIfPresent(oldData, newData, PERMANENT_ZENKAI);
        copyIfPresent(oldData, newData, ZENKAI_COUNT);
        copyIfPresent(oldData, newData, DAMAGE_SINCE_LAST_ZENKAI);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            applyZenkaiBonus(player);
        }
    }

    private static void copyIfPresent(CompoundTag from, CompoundTag to, String key) {
        if (from.contains(key)) {
            to.put(key, from.get(key).copy());
        }
    }

    private static void applyZenkaiBonus(ServerPlayer player) {
        double total = player.getPersistentData().getDouble(PERMANENT_ZENKAI);
        AttributeInstance attack = player.getAttribute(Attributes.ATTACK_DAMAGE);
        if (attack == null) {
            return;
        }
        attack.removeModifier(ZENKAI_ATTACK_UUID);
        if (total > 0.0D) {
            // Diminishing scaling prevents runaway attribute values while the Zenkai record stays permanent.
            double bonus = Math.log1p(total) * 0.25D;
            attack.addTransientModifier(new AttributeModifier(
                    ZENKAI_ATTACK_UUID,
                    "Legacy of the Saiyans permanent Zenkai",
                    bonus,
                    AttributeModifier.Operation.ADDITION
            ));
        }
    }
}
