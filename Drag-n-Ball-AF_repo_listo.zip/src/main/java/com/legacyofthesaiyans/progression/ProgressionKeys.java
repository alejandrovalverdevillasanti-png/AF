package com.legacyofthesaiyans.progression;
public final class ProgressionKeys {
    public static final String POTENTIAL = "legacyofthesaiyans.potential";
    public static final String BREAK_LEVEL = "legacyofthesaiyans.break_level";
    public static final String BREAK_CHARGE = "legacyofthesaiyans.break_charge";
    private ProgressionKeys() {}
}
